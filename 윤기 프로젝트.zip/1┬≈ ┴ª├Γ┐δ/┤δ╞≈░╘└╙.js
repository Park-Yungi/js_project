function draw() {
    ctx.clearRect(0, 0, width, height);
    tank_centerX = tank_leftcorner + 0.5 * tank_width;
    tank_centerY = height - 0.5 * tank_height;
  if (t_leftpressed && (tank_leftcorner > 0)) {
    tank_leftcorner -= tank_Moving_Speed;
  }
  if (t_rightpressed && (tank_leftcorner + tank_width < width)) {
    tank_leftcorner += tank_Moving_Speed;         // (좌,우) 방향키에 따른 탱그의 위치 조정
  }


  if (isCharging && !isFired) {
    if (gauge < Math.PI * 2) {
      gauge += gauge_DIF;
    }
    drawGauging();       // 스페이스바가 눌리면 gauge bar가 충전되고 그리도록 함수 호출
  }
  if (!isFired) {
    missileX = tank_centerX + Launcher_Length * Math.cos(Launcher_Angle);
    missileY = tank_centerY - Launcher_Length * Math.sin(Launcher_Angle);
  } else {
    missile_dy -= Acceleration_g;
    missileX = missileX + missile_dx;
    missileY = missileY - missile_dy;
  }
     checkHit();
     drawTank();
     drawTarget();
     drawMissile();
    
}
function drawTank() {
    ctx.beginPath();
    ctx.moveTo(tank_leftcorner, height - tank_height);
    ctx.lineTo(tank_leftcorner + tank_width, height - tank_height);
    ctx.lineTo(tank_leftcorner + tank_width, height);
    ctx.lineTo(tank_leftcorner, height);
    ctx.lineTo(tank_leftcorner, height - tank_height);
    ctx.moveTo(tank_centerX,tank_centerY);
    ctx.lineTo(
        tank_centerX + Launcher_Length * Math.cos(Launcher_Angle),
        tank_centerY - Launcher_Length * Math.sin(Launcher_Angle)
    )
    ctx.stroke(); 
    ctx.closePath();          // 해당 위치에 해당하는 탱크 그리기
}

function drawTarget() {
    
    ctx.beginPath();
    if (isHitted) {
      ctx.fillStyle = "white";
      clearInterval(start);
    }else {

      ctx.fillStyle = "red";
    }
    ctx.fillRect(targetX, targetY, target_Width, target_Height);
    
    
    ctx.fill();
    ctx.closePath();


}


function drawGauging() {
  ctx.beginPath();
  ctx.arc(
    tank_centerX,
    tank_centerY - Launcher_Length,
    gaugeBar_Radius,
    Math.PI,
    gauge,
    false
  );
  ctx.stroke();
}

function drawMissile() {
  ctx.beginPath();
  if(isHitted){
  ctx.fillStyle = "white"
  }else{
    ctx.fillStyle = "blue"
  }
  ctx.arc(missileX, missileY, missile_Radius, 0, Math.PI * 2);
  ;
  ctx.fill();
  ctx.closePath();
}

function checkHit() {
  if (missileX <= 0 || missileX >= width || missileY >= height) {
    isFired = false;
  }
  if (
    missileX >= targetX &&
    missileX <= targetX + target_Width &&
    missileY >= (targetY - (target_Height / 2)) &&
    missileY <= (targetY + (target_Height / 2))
  ) {
    isHitted = true;
    if (isHitted) {
      
  
      setTimeout(() => {
          if (confirm("명중입니다. 다시 하시겠습니까?")) {
              location.reload();
          }
      }, 100);
  }
}
}


   






let canvas = document.querySelector("#mycanvas");
let ctx = canvas.getContext("2d");
let width = canvas.width;
let height = canvas.height;     // 공간 설정
//------------------------------------------------------------
let tank_width = 50;
let tank_height = 60;
let tank_leftcorner = 0;
let tank_Moving_Speed = 5;
let t_leftpressed = false;
let t_rightpressed = false;     // 탱크 크기와 위치 설정
//--------------------------------------------------------------------
let tank_centerX;
let tank_centerY;
let Launcher_Angle = Math.PI / 4;
let Launcher_AngleDIF = Math.PI / 60;
let Launcher_Length = tank_width * Math.sqrt(2);   // 탱크의 발사체에 대한 설정
//--------------------------------------------------------------------
let target_Width = 50;
let target_Height = 50;
let targetX = Math.floor(Math.random() * (canvas.width - target_Width - 100) + 100);
let targetY = Math.floor(Math.random() * (canvas.height - target_Height - 100) + 100);    // target위치를 랜덤으로 직교좌표계로 표현
//------------------------------------------------------------------------ 


let missile_Radius = 5;
let missileX;
let missileY;
let isCharging = false;
let isFired = false;
let isHitted = false;
let gauge = Math.PI;
let gauge_DIF = Math.PI / 60;
let gaugeBar_Radius = 30;
let missile_Power;
let missile_dx;
let missile_dy;
let Acceleration_g = 0.098;
// --------------------------------------------------------------- 미사일과 gauge bar에 대한 설정



let keydownHandler = event => {
    if (event.keyCode === 37) {
      t_leftpressed = true;
    } else if (event.keyCode === 39) {
      t_rightpressed = true;
    } else if (event.keyCode === 38 && (Launcher_Angle <= Math.PI)) {
      Launcher_Angle += Launcher_AngleDIF;
    } else if (event.keyCode === 40 && (Launcher_Angle >= 0)) {
      Launcher_Angle -= Launcher_AngleDIF;
    } else if (event.keyCode === 32 && !isFired ) {
      isCharging = true;      // keyCode == 32(space bar) 가 눌리면 충전
    }

  };                                                   // (1)boolean값을 통한 (좌,우) 버튼의 눌림 여부 확인
let keyupHandler = event => {                         // (2) (상,하)의 경우는 누를 때의 이벤트만 고려     
    if (event.keyCode === 37) {
        t_leftpressed = false;
    } else if (event.keyCode === 39) {
        t_rightpressed = false;
    } else if (event.keyCode === 32 && !isFired) {
      isCharging = false;
      isFired = true;
      missile_Power = gauge * 2;
      missile_dx = missile_Power * Math.cos(Launcher_Angle);
      missile_dy = missile_Power * Math.sin(Launcher_Angle);
      gauge = Math.PI;       // keyCode == 32(space bar) 를 때면  미사일 발사


    }
  };
let start = setInterval(draw, 10);
document.addEventListener("keydown", keydownHandler, false);
document.addEventListener("keyup", keyupHandler, false);      

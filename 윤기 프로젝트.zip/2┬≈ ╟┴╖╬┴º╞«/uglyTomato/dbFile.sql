CREATE DATABASE uglyTomato;

USE uglyTomato;

DROP table Member;
DROP table Item;
DROP table Reply;
DROP table Basket;
DROP table Board;

CREATE table Member(
	member_no int primary key,
	member_id varchar(50) not null,
	member_pw varchar(100) not null,
	member_name varchar(50) not null,
	member_email varchar(200) not null,
	member_addr1 varchar(50),
	member_addr2 varchar(300),
	member_addr3 varchar(300),
	member_gender varchar(10),/*1 남자 2 여자 0 선택안함*/
	member_marketing boolean /* 마케팅 수신 동의 (안쓰임) */
);

INSERT Member VALUE(1000, "admin", "admin", "관리자", "admin@naver.com","","","","",true);
INSERT Member VALUE(1001,"qwer1234", "Qwer1234!","홍길동","nav@naver.com","02830","서울 성북구 아리랑로 3","100동 209호","1",true);
INSERT Member VALUE(1002,"abcd1234", "Abcd1234!","김수정","abcd@naver.com","02830","서울 성북구 아리랑로 3","100동 209호","2",false);
INSERT Member VALUE(1003,"hello1234", "Hello1234!","박철수","hello@naver.com","02830","서울 성북구 아리랑로 3","100동 209호","1",true);

SELECT * FROM MEMBER;

CREATE table Item(
	item_no int primary key,
	member_no int not null,
	item_name varchar(100) not null,
	item_price int not null,
	item_img1 varchar(100), /* 메인 이미지 */
	item_img2 varchar(100), /* 상세설명 이미지 */
	item_sold int, /* 팔린 개수 */
	item_stock int, /* 재고 */
	item_growing varchar(100) /* 원산지 */
);

INSERT Item VALUE(1, 1001,  "유기농 가지", 6900, "1.jpg", "가지상세.jpg", 5, 50, "원산지 : 양산");
INSERT Item VALUE(2, 1003, "못난이 감자", 8700, "2.jpg", "감자상세.jpg",8, 50, "원산지 : 정선");
INSERT Item VALUE(3, 1002, "유기농 호박고구마", 11200, "3.jpg", "고구마상세.jpg",12, 50, "원산지 : 해남");
INSERT Item VALUE(4, 1000, "제주 햇당근", 9500, "4.jpg", "당근상세.jpg",8, 50, "원산지 : 제주");
INSERT Item VALUE(5, 1002, "아삭 미니 오이", 7800, "5.jpg", "오이상세.jpg", 6, 50, "원산지 : 양주");
INSERT Item VALUE(6, 1002, "어글리 토마토", 14000, "6.jpg", "토마토상세.jpg", 10, 50, "원산지 : 나주");
INSERT Item VALUE(7, 1003, "파프리카 3종", 15000, "7.jpg", "파프리카상세.jpg", 7, 50, "원산지 : 남원");
INSERT Item VALUE(8, 1001, "특가! 쥬키니 호박", 10000, "8.jpg", "호박상세.jpg", 15, 0, "원산지 : 무안");

SELECT * FROM Item;

CREATE table Basket(
	basket_no int PRIMARY KEY AUTO_INCREMENT,
	member_no int not null,
	item_no int not null,
	item_stack int not null, /* 물건 개수 */
	item_delivery int /* 배송비 */
);

INSERT Basket VALUE(default,1001, 7, 8, 3000);
INSERT Basket VALUE(default,1001, 8, 6, 3000);

SELECT * FROM Basket;

CREATE table Reply(
	reply_no int primary key,
	item_no int not null,
	member_no int not null,
	reply_content varchar(500),
	reply_img varchar(500), /* 후기 이미지 */
	reply_star int /* 별점 */
);

INSERT Reply VALUE(1, 4, 1001, "진짜 맛있어요 부모님 한테 시켜드렸는데 완전 만족하셨네요", "4.jpg", 4);
INSERT Reply VALUE(2, 4, 1002, "진짜 맛있어요 부모님 한테 시켜드렸는데 완전 만족하셨네요진짜 맛있어요 부모님 한테 시켜드렸는데 완전 만족하셨네요진짜 맛있어요 부모님 한테 시켜드렸는데 완전 만족하셨네요진짜 맛있어요 부모님 한테 시켜드렸는데 완전 만족하셨네요", "4.jpg", 4);

SELECT * FROM Reply;

CREATE table Board(
	board_no int primary key,
	board_title varchar(300) not null,
	board_content varchar(1000),
    board_regdate varchar(100)
);

insert Board value(1, "어글리토마토 서버점검 안내", "내용1", "2024-05-10");
insert Board value(2, "어글리토마토 업데이트 안내", "내용2", "2024-05-12");
insert Board value(3, "배송비 무료 이벤트", "내용3", "2024-05-15");
insert Board value(4, "(필독)반품 및 환불 안내", "내용4", "2024-05-17");
insert Board value(5, "여름세일 시작", "내용5", "2024-05-20");
insert Board value(6, "한가위 배송지연안내", "내용6", "2024-05-25");
insert Board value(7, "SNS공유 이벤트 당첨자", "내용7", "2024-05-29");

SELECT * FROM Board;
